# Base configuration

Initial hardening and access setup applied to the 3750 after first boot.

## Hostname and basic hygiene

```
Switch> enable
Switch# configure terminal
Switch(config)# hostname host1
host1(config)# no ip domain-lookup
```

`no ip domain-lookup` stops the switch from trying to DNS-resolve mistyped
commands, which otherwise causes a multi-second hang on every typo.

## Local authentication

```
host1(config)# enable secret <strong-password>
host1(config)# username admin secret <strong-password>
host1(config)# line console 0
host1(config-line)# login local
host1(config-line)# exit
```

## SSH access

```
host1(config)# line vty 0 15
host1(config-line)# login local
host1(config-line)# transport input ssh
host1(config-line)# exit

host1(config)# ip domain-name lab.local
host1(config)# crypto key generate rsa modulus 2048
```

## Management IP

```
host1(config)# interface vlan 1
host1(config-if)# ip address 192.168.1.2 255.255.255.0
host1(config-if)# no shutdown
host1(config)# ip default-gateway 192.168.1.1
```

## Save configuration

```
host1# write memory
```

---

**Status:** Hostname and local auth applied. SSH and management IP are next
once the lab network addressing is finalized.
