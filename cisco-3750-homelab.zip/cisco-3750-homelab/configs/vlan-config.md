# VLAN configuration

## VLANs created

```
host1(config)# vlan 10
host1(config-vlan)# name HR
host1(config)# vlan 20
host1(config-vlan)# name Sales
host1(config)# exit
```

## Current state (`show vlan brief`)

See [`../images/vlan-table.png`](../images/vlan-table.png) for the full
output. Summary:

| VLAN | Name | Status | Assigned ports |
|------|------|--------|-----------------|
| 1    | default | active | All unassigned Fa3/0/x and Gi3/0/x ports |
| 10   | HR | active | Fa3/0/1 |
| 20   | Sales | active | *(none yet)* |
| 1002 | fddi-default | act/unsup | Cisco system default, not used |

## Assigning an access port to a VLAN

```
host1(config)# interface FastEthernet3/0/1
host1(config-if)# switchport mode access
host1(config-if)# switchport access vlan 10
```

## Planned: trunking an uplink

Once a second device (AP, another switch, or router-on-a-stick) is added:

```
host1(config)# interface GigabitEthernet3/0/1
host1(config-if)# switchport trunk encapsulation dot1q
host1(config-if)# switchport mode trunk
host1(config-if)# switchport trunk allowed vlan 10,20
```

## Planned: inter-VLAN routing

The 3750 can route between VLANs natively (no external router needed):

```
host1(config)# ip routing
host1(config)# interface vlan 10
host1(config-if)# ip address 10.0.10.1 255.255.255.0
host1(config)# interface vlan 20
host1(config-if)# ip address 10.0.20.1 255.255.255.0
```

---

**Status:** VLANs 10 (HR) and 20 (Sales) created. Fa3/0/1 assigned to
VLAN 10. Sales (VLAN 20) has no ports assigned yet. Trunking and
inter-VLAN routing not yet configured.
