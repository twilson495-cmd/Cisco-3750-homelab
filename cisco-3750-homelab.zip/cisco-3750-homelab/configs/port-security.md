# Port security

Goal: lock down access ports so only expected devices can connect —
a standard access-layer hardening step and a good talking point for
interviews.

## Applied so far

```
host1(config)# interface FastEthernet3/0/1
host1(config-if)# switchport port-security
```

See [`../images/port-security-config.png`](../images/port-security-config.png)
for the console output.

> Note: `switchport port-security` only works on ports already in
> **access** mode (`switchport mode access`) — trunk or dynamic ports will
> reject the command.

## Planned follow-up commands

```
host1(config-if)# switchport port-security maximum 2
host1(config-if)# switchport port-security mac-address sticky
host1(config-if)# switchport port-security violation restrict
```

- `maximum 2` — allow up to 2 learned MAC addresses on the port
- `mac-address sticky` — dynamically learn and "stick" the first MAC(s)
  seen into the running config, instead of hardcoding them
- `violation restrict` — drop traffic from unauthorized MACs and log it,
  without shutting the port down (alternative: `shutdown`, which err-disables
  the port on a violation — stricter but more disruptive)

## Verifying

```
host1# show port-security interface FastEthernet3/0/1
host1# show port-security address
```

---

**Status:** Basic `switchport port-security` enabled on Fa3/0/1. Sticky
MAC, violation mode, and max-MAC count are the next step.
